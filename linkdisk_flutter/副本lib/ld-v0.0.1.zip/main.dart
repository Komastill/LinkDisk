import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LinkDisk 传输工具',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const DeviceFindPage(),
    );
  }
}

class DeviceFindPage extends StatefulWidget {
  const DeviceFindPage({super.key});

  @override
  State<DeviceFindPage> createState() => _DeviceFindPageState();
}

class _DeviceFindPageState extends State<DeviceFindPage> {
  // 关键：用随机端口，避免双进程同端口冲突
  final int _listenPort = 8889 + DateTime.now().microsecond % 100;
  final List<String> _deviceList = [];
  String? _localIp;
  RawDatagramSocket? _socket;
  bool _isScanning = false;

  List<File>? _selectedFiles;
  double _sendProgress = 0;
  bool _isSending = false;

  ServerSocket? _serverSocket;
  final String _receiveDir = "D:\\LinkDisk_Received";

  @override
  void initState() {
    super.initState();
    _initNetwork();
    _startFileReceiver();
  }

  Future<void> _initNetwork() async {
    _localIp = await _getLocalIP();
    setState(() {});

    // 绑定到本机IP + 随机端口
    _socket = await RawDatagramSocket.bind(InternetAddress(_localIp!), _listenPort);
    _socket?.broadcastEnabled = true;

    _socket?.listen((event) {
      if (event == RawSocketEvent.read) {
        Datagram? datagram = _socket?.receive();
        if (datagram != null) {
          String ip = datagram.address.address;
          // 收到探测包，把对方加入列表
          if (!_deviceList.contains(ip) && ip != _localIp) {
            setState(() {
              _deviceList.add(ip);
            });
          }
        }
      }
    });
  }

  // 关键：主动向常见端口发送探测包，而不是等广播
  void _scanDevices() async {
    setState(() => _isScanning = true);
    final data = utf8.encode("DEVICE_DISCOVERY");
    // 向8889~8900范围内的端口发送探测包（覆盖另一个进程的随机端口）
    for (int port = 8889; port <= 8900; port++) {
      if (port != _listenPort) { // 不发给自己
        _socket?.send(data, InternetAddress(_localIp!), port);
      }
    }
    await Future.delayed(const Duration(seconds: 2));
    setState(() => _isScanning = false);
  }

  Future<String?> _getLocalIP() async {
    for (var interface in await NetworkInterface.list()) {
      for (var addr in interface.addresses) {
        if (addr.type == InternetAddressType.IPv4 && !addr.address.startsWith("127.")) {
          return addr.address;
        }
      }
    }
    return null;
  }

  Future<void> _startFileReceiver() async {
    try {
      Directory(_receiveDir).createSync(recursive: true);
      _serverSocket = await ServerSocket.bind(InternetAddress.anyIPv4, 9999);
      _serverSocket!.listen((socket) {
        _handleClient(socket);
      });
    } catch (e) {}
  }

  Future<void> _handleClient(Socket socket) async {
    try {
      final file = File('$_receiveDir\\recv_${DateTime.now().millisecondsSinceEpoch}.dat');
      final raf = file.openWrite();
      await for (var chunk in socket) {
        raf.add(chunk);
      }
      await raf.close();
      socket.destroy();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("文件已接收：${file.path}")),
        );
      }
    } catch (e) {
      socket.destroy();
    }
  }

  Future<void> _pickFiles() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      setState(() {
        _selectedFiles = result.paths.map((p) => File(p!)).toList();
      });
    }
  }

  Future<void> _sendToDevice(String ip) async {
    if (_selectedFiles == null || _selectedFiles!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("请先选择文件")));
      return;
    }

    setState(() {
      _isSending = true;
      _sendProgress = 0;
    });

    try {
      final socket = await Socket.connect(ip, 9999);
      int total = _selectedFiles!.fold(0, (s, f) => s + f.lengthSync());
      int sent = 0;

      for (final file in _selectedFiles!) {
        await for (var chunk in file.openRead()) {
          socket.add(chunk);
          sent += chunk.length;
          setState(() => _sendProgress = sent / total);
          await socket.flush();
        }
      }

      await socket.close();
      setState(() => _isSending = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("发送完成！")));
    } catch (e) {
      setState(() => _isSending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("发送失败：$e")));
    }
  }

  @override
  void dispose() {
    _socket?.close();
    _serverSocket?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("LinkDisk 传输工具")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("本机IP：$_localIp"),
            Text("监听端口：$_listenPort"),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _isScanning ? null : _scanDevices,
              child: Text(_isScanning ? "扫描中…" : "扫描设备"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _pickFiles,
              child: const Text("选择文件"),
            ),
            if (_selectedFiles != null)
              Text("已选：${_selectedFiles!.length} 个"),
            if (_isSending)
              Column(
                children: [
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: _sendProgress),
                  Text("${(_sendProgress * 100).toInt()}%"),
                ],
              ),
            const SizedBox(height: 20),
            const Text("可发送设备："),
            Expanded(
              child: _deviceList.isEmpty
                  ? const Center(child: Text("暂无设备"))
                  : ListView.builder(
                      itemCount: _deviceList.length,
                      itemBuilder: (ctx, i) {
                        return ListTile(
                          title: Text(_deviceList[i]),
                          onTap: _isSending ? null : () => _sendToDevice(_deviceList[i]),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}