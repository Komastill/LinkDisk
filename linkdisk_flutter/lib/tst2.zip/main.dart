import 'package:flutter/material.dart';
import 'ui/MainFrame.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LinkDisk',
      debugShowCheckedModeBanner: false,
      home: MainFrame(),
    );
  }
}