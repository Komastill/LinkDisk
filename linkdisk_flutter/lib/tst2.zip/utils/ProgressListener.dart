import 'dart:io';
import 'dart:typed_data';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
// 对应 Java 的 ProgressListener 接口
abstract class ProgressListener {
  void onTotalProgress(int progress);

  void onFileStart(int fileIndex, String fileName);

  void onFileProgress(int fileIndex, String fileName, int progress);

  void onFileComplete(int fileIndex, String fileName);
}