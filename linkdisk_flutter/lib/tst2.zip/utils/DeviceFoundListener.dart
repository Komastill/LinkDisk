import 'dart:io';
import 'dart:typed_data';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
// 设备发现监听器（对应 Java interface）
abstract class DeviceFoundListener {
  void onDeviceFound(String ip, String deviceName, String platform);
}